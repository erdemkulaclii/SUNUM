# Indicators of Compromise: Russia-Based Influence Operation Network Targeting Sub-Saharan Africa

Meta disrupted a Russia-based Coordinated Inauthentic Behavior (CIB) network targeting Sub-Saharan Africa. This file contains Indicators of Compromise (IOCs) from Meta’s Adversarial Threat Report H1 2026.

## Meta’s Adversarial Threat Report Network Summary

We disrupted a network originating in Russia that targeted audiences in Sub-Saharan Africa, including Angola, Ghana, Kenya, and South Africa. We actioned 37 Facebook accounts and 29 Pages for violating our policy against Coordinated Inauthentic Behavior. About 30,000 accounts followed one or more of these Pages. The network engaged in around $7,000 in spending for ads on Facebook and Instagram, paid for mostly in Euros and US Dollars. These assets posed as local, grassroots news sources. The campaign sought to influence public opinion by amplifying historical grievances against former colonial powers and other anti-Western narratives, as well as promoting Russia as a viable alternative economic and political ally.

The operation, which began in August 2025, promoted primarily authentic, off-platform news articles and social media channels that already supported narratives aligned with this campaign. In some cases, the network shared opinion articles published by legitimate news websites that carried bylines falsely attributed to real individuals or attributed to entirely fictitious personas. This tactic is consistent with [external reports](https://alleyesonwagner.org/2026/02/14/a-new-chef-in-the-kitchen-the-svr-takes-control-of-the-wagners-influence-branch-for-offensive-operations-in-the-global-south/) that Russian entities paid to place content in African outlets like Pulse Live Kenya. The network also used AI-generated content to make its accounts appear more authentic to local users, including in the Page's visual branding, such as profile photos and advertisements promoting the Page, as well as in its influence operation materials. We shared this information with our partners at OpenAI who conducted an independent investigation into the network, leading to the [removal](https://cdn.openai.com/pdf/df438d70-e3fe-4a6c-a403-ff632def8f79/disrupting-malicious-uses-of-ai.pdf) of the network from their platforms.

## Indicators of Compromise

*Note: URLs have been defanged for safety. Replace `[.]` with `.` to resolve.*

| Indicator Type | Indicator Value |
| :--- | :--- |
| URL | `www[.]change[.]org/p/joão-lourenço-demita-se-do-cargo-de-presidente-da-república-já?recruiter=1368271402&recruited_by_id=8dce6f60-013b-11f0-9bb1-a938b470633d` |
| URL | `www[.]iol[.]co[.]za/sundayindependent/analysis/2025-06-25-us-africa-business-summit-a-showdown-in-luanda/` |
| URL | `www[.]iol[.]co[.]za/sundayindependent/dispatch/2025-07-01-angola-must-get-its-house-to-benefit-from-the-us-africa-business-summit` |
| URL | `www[.]angola24horas[.]com/opiniao/item/32323-a-retorica-de-trump-na-africa-anula-todo-o-progresso-joe-biden` |
| URL | `www[.]pulselive[.]co[.]ke/articles/news/local/batuk-laughs-at-rape-victims-why-is-agnes-wanjirus-murderer-still-not-in-jail-opinion-2025100914013150883` |

## Cross-Links

- **Full ATR Report:** [Meta Adversarial Threat Report H1 2026](TBD)
- **AlienVault OTX Pulse:** [meta-h1-2026-russia-based-cib-network-1 on OTX](https://otx.alienvault.com/pulse/meta-h1-2026-russia-based-cib-network-1)
- **IOC File (GitHub):** [meta-h1-2026-russia-based-cib-network-1 on GitHub](https://github.com/facebook/threat-research/blob/main/indicators/meta-h1-2026-russia-based-cib-network-1.md)
