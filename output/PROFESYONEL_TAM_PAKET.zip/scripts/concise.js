'use strict';
const D=JSON.parse(document.getElementById('dataset').textContent),$=id=>document.getElementById(id),S=D.slides;
const T=D.timing.talk,M=D.meta||{};let scene=0,elapsed=0,playing=false,timer=null,map=null,priorFocus=null,atlasTargets={};
const offsets=[0];for(const s of S)offsets.push(offsets.at(-1)+s.seconds);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=s=>String(Math.floor(s/60)).padStart(2,'0')+':'+String(Math.floor(s%60)).padStart(2,'0');
const countryNames={Germany:'Almanya',UK:'Birleşik Krallık',France:'Fransa',Italy:'İtalya',Latvia:'Letonya',Ukraine:'Ukrayna',Multiple:'Çoklu hedef'};
function svg(body,view='0 0 650 410'){return '<svg viewBox="'+view+'" role="img">'+body+'</svg>'}
function bars(items,max,caption=''){return svg(items.map((r,i)=>{const y=36+i*47;return `<text class="label" x="0" y="${y+19}">${esc(r[0])}</text><rect class="bar" x="175" y="${y}" width="${r[1]/max*390}" height="23"/><text class="value" x="630" y="${y+20}" text-anchor="end">${r[1]}</text>`}).join('')+`<text class="small" x="0" y="397">${esc(caption)}</text>`)}
function steps(items,note=''){return '<ol class="steps">'+items.map(([h,t],i)=>'<li><b>'+String(i+1).padStart(2,'0')+'</b><div><strong>'+esc(h)+'</strong>'+(t?'<span>'+esc(t)+'</span>':'')+'</div></li>').join('')+'</ol>'+(note?'<p class="mini-note">'+esc(note)+'</p>':'')}
function visual(s){
 const f=D.analysis.findings;
 if(s.visual==='steps'&&s.steps)return steps(s.steps);
 if(s.visual==='quote')return '<blockquote class="def-quote"><p>'+esc(s.quote)+'</p><footer>'+esc(s.quote_note||'')+'</footer></blockquote>';
 if(s.visual==='table'&&s.table)return '<table class="visual-table compare layers"><thead><tr>'+s.table.headers.map(h=>'<th>'+esc(h)+'</th>').join('')+'</tr></thead><tbody>'+s.table.rows.map(r=>'<tr>'+r.map((c,i)=>'<td'+(i===2&&/^Ölçüldü/.test(c)?' class="measured"':'')+'>'+esc(c)+'</td>').join('')+'</tr>').join('')+'</tbody></table>';
 if(s.visual==='cover')return '<div class="cover-card"><p class="cover-author">'+esc(M.author)+'</p><p>'+esc(M.affiliation)+'</p><p>'+esc(M.course)+'</p><p>'+esc(M.date)+'</p><hr><p class="cover-data"><b>311</b> alan adı göstergesi · <b>5,9 milyon</b> GDELT haber kaydı</p></div>';
 if(s.visual==='outline')return steps([['Giriş','Vaka ve kavramsal çerçeve'],['Yöntem','Meta CSV + GDELT GKG ham arşivi (MD5 doğrulamalı)'],['Bulgular','Hedef ülke, DNS yapısı, haber dalgası, haber haritası'],['Tartışma','Literatürle ilişki, sınırlılıklar, sonuç']]);
 if(s.visual==='context')return '<div class="timeline"><div><time>Mayıs 2022</time><p>Kampanyanın bilinen başlangıcı</p><small>Alaphilippe vd., 2022</small></div><div><time>27.09.2022</time><p>EU DisinfoLab raporu: en az 17 medya markası taklit edildi</p><small>Bild · Spiegel · The Guardian · ANSA</small></div><div class="accent"><time>27.09.2022</time><p>Meta kaldırma raporu ve açık gösterge listesi</p><small>Nimmo ve Agranovich, 2022</small></div></div>';
 if(s.visual==='literature')return '<div class="lit-grid"><div><h3>Dezenformasyon düzeni</h3><p>Haber/belgesel biçimini taklit eden kasıtlı yanlışlar; üretim → dağıtım</p><small>Bennett ve Livingston, 2018; Wardle ve Derakhshan, 2017; Freelon ve Wells, 2020</small></div><div><h3>Ölçüm ve payda</h3><p>Neyin, hangi evrende sayıldığı açık tanımlanmalı</p><small>Lazer vd., 2018; Allen vd., 2020</small></div><div><h3>GDELT ve haber coğrafyası</h3><p>Haber coğrafyası bölgeseldir; otomatik kodlama doğrulanmalıdır</p><small>Leetaru ve Schrodt, 2013; Kwak ve An, 2014; Wang vd., 2016</small></div><div class="gap"><h3>Bu çalışmanın konumu</h3><p>Taklit altyapısı (üretim) ile haber görünürlüğünü (dağıtım/yorum) aynı vakada yan yana okumak</p></div></div>';
 if(s.visual==='method')return '<div class="flow"><div class="flow-col"><h3>Meta CSV · 27.09.2022</h3><p>350 kayıt → 311 benzersiz alan adı</p><ul><li>Hedef etiketi (comment)</li><li>İlk / son DNS etiketi</li></ul><span>AS1 · AS2</span></div><div class="flow-col"><h3>GDELT GKG 2.0 ham arşivi</h3><p>20.09–11.10.2022 · 4.209 dosya · MD5 doğrulamalı · 5,9 milyon kayıt</p><ul><li>Kural R1/R2 ile eşleşme</li><li>Gün ve ülke paydaları</li></ul><span>AS3 · dalga</span></div><div class="flow-col"><h3>Coğrafya</h3><p>GDELT 2018 alan adı–ülke listesi; GKG V2Locations</p><ul><li>Kaynak ülke (renk)</li><li>Anılan yer (nokta)</li></ul><span>AS3 · harita</span></div></div><p class="mini-note">Ölçüm birimleri ayrı tutulur: hedef etiketi ≠ kaynak ülke ≠ anılan yer.</p>';
 if(s.visual==='gdelt_map')return '<div id="gdelt-slot" class="gdelt-slot"></div>';
 if(s.visual==='gdelt_wave')return window.gdeltWaveSVG?window.gdeltWaveSVG():'';
 if(s.visual==='validity'){const g=D.gdelt||{},a=g.archive||{},v=(g.validation?.by_rule||{}).all,nf=new Intl.NumberFormat('tr-TR');return steps([['MD5 doğrulaması',nf.format(a.files_md5_verified||0)+' / '+nf.format(a.files||0)+' ham GKG dosyası GDELT’in yayımladığı özetle eşleşti'],['Tarama kapsamı',nf.format(a.rows_scanned||0)+' haber kaydı · İngilizce + çeviri akışı · 20.09–11.10.2022'],['Eşleşme isabeti',v&&v.n?('%'+Math.round(v.precision*100)+' ilgili (n='+v.n+'; %95 GA %'+Math.round(v.wilson95[0]*100)+'–%'+Math.round(v.wilson95[1]*100)+') · sabit tohumlu rastgele örneklem'):'Örneklem denetimi bekleniyor'],['Yeniden üretim','python scripts/gdelt_gkg_archive.py · birim testleri: test_gdelt_archive.py']],'Aynı komut, aynı dosyalarla aynı sayıları üretmelidir; sapma testlerde görünür.')}
 if(s.visual==='discussion')return '<table class="visual-table compare"><thead><tr><th>Bulgu</th><th>Literatür / raporlar</th><th>İlişki</th></tr></thead><tbody><tr><td>Almanya %95,8 hedef</td><td>Öncelikli hedef Almanya (Nimmo ve Agranovich, 2022; Auswärtiges Amt, 2024)</td><td>Uyumlu</td></tr><tr><td>Haber kaynağı: ABD 373 / 511</td><td>Haber coğrafyası bölgeseldir (Kwak ve An, 2014)</td><td>Asimetri</td></tr><tr><td>511 adres, 145 başlık</td><td>Dağıtım altyapısı (Wardle ve Derakhshan, 2017)</td><td>Ajans çoğaltması</td></tr><tr><td>“Doppelgänger” adı: 1 ilgili haber</td><td>Ad, EU DisinfoLab raporuyla (2022) doğdu</td><td>Sonradan yaygınlaştı*</td></tr></tbody></table><p class="mini-note">* 2022 penceresiyle sınırlı gözlem; sonraki yılların taraması yapılmadı.</p>';
 if(s.visual==='question')return steps([['AS1 · Hedef coğrafyası','Birim: alan adı · Meta hedef etiketi'],['AS2 · Sözcüksel yapı','Birim: alan adı · ilk ve son DNS etiketi'],['AS3 · Haber görünürlüğü','Birim: haber makalesi · GDELT GKG: gün, kaynak ülke, anılan yer']],'İlk iki soru aynı 311 kayıt üzerinde; üçüncüsü ayrı bir birimle ölçülür.');
 if(s.visual==='audit')return svg('<text class="big" x="20" y="118">350</text><text class="label" x="20" y="158">ham kayıt</text><text class="big" x="245" y="118">313</text><text class="label" x="245" y="158">alan adı satırı</text><text class="big accent" x="465" y="118">311</text><text class="label" x="465" y="158">benzersiz</text><path class="rule" d="M25 222H610"/><text class="label" x="35" y="285">22 CIB URL + 15 Telegram URL ayrı.</text><text class="small" x="35" y="349">İki tekrar çıkarıldı; kaynak satırı izleri korundu.</text>');
 if(s.visual==='countries'){const order=['Germany','UK','France','Italy','Latvia','Ukraine','Multiple'];return bars(order.map(k=>[countryNames[k],f.target_country_counts[k]]),298,'Lineer ölçek / benzersiz alan adı')}
 if(s.visual==='tlds')return bars(f.top_six_last_dns_labels.map(x=>['.'+x.last_dns_label,x.domain_count]),53,'Son DNS etiketi / en sık altı kategori');
 if(s.visual==='reuse'){const examples=['spiegel','bild','dailymail'].map(k=>D.analysis.first_label_families.find(x=>x.first_dns_label===k));return '<table class="visual-table"><thead><tr><th>İlk etiket</th><th>Son etiket</th><th>Adres</th></tr></thead><tbody>'+examples.map(x=>`<tr><td><code>${esc(x.first_dns_label)}</code></td><td>${x.distinct_last_label_count}</td><td>${x.domain_count}</td></tr>`).join('')+'</tbody></table><p class="mini-note">Tam dize eşleşmesi; 75 çoklu son etiket grubu, 293 adres.</p>'}
 if(s.visual==='anatomy')return '<div class="anatomy"><span>theguardian</span><i>[.]</i><span>co</span><i>[.]</i><span>com</span></div><div class="anatomy-labels"><span>İlk DNS etiketi</span><span>Ara etiket</span><span>Son DNS etiketi</span></div><p class="mini-note">Kaynak gösterge: theguardian[.]co[.]com. Etkin kayıt sınırı veya yasal yayıncı kimliği hesaplanmadı.</p>';
 if(s.visual==='limits')return '<div class="lit-grid two"><div><h3>Meta listesi</h3><p>Tespit ve yayımlama seçilimi<br>Bütün kayıtlarda ds = 27.09.2022</p><small>Allen vd., 2020</small></div><div><h3>GDELT</h3><p>Yalnız izlenen kaynaklar; ABD fazla temsil<br>Ülke listesi 2018 tarihli<br>Kural isabeti %90,6; yanlış negatif ölçülmedi</p><small>Wang vd., 2016; The GDELT Project, 2018</small></div><div><h3>Coğrafya</h3><p>Kaynak ülke ≠ okur ülkesi<br>Otomatik konum kodlaması hata içerebilir</p><small>Hammond ve Weidmann, 2014</small></div><div class="gap"><h3>Sonuç</h3><p>Betimsel bulgular; niyet, maruziyet veya etki iddiası yok</p></div></div>';
 if(s.visual==='future')return svg('<text class="label" x="35" y="90">Tarihsel kapsam</text><path class="rule" d="M35 125H600"/><text class="label" x="35" y="190">Kaynak eşleştirme</text><path class="rule" d="M35 225H600"/><text class="label" x="35" y="290">İçerik kodlaması</text><text class="small" x="35" y="365">Bu karşılaştırma henüz yapılmadı.</text>');
 if(s.visual==='conclusion')return steps([['AS1 · %95,8','298/311 gösterge Almanya hedefli'],['AS2 · 240 + 293','Altı son etiket 240 adres; 75 ilk etiket grubu 293 adres'],['AS3 · 27–28 Eylül dalgası','511 haberin %96,3’ü iki günde; 373’ü ABD kaynaklı, %63,6’sı Almanya’yı anıyor'],['Sonraki adım','İkinci kodlayıcı, yanlış negatif ölçümü ve içerik çözümlemesi']]);
 return '<div class="ref-list">'+[...D.references].sort((a,b)=>a.apa.replace(/<[^>]+>/g,'').replace(/^The /,'').localeCompare(b.apa.replace(/<[^>]+>/g,'').replace(/^The /,''),'en')).map(r=>'<p>'+r.apa+' <a href="'+esc(r.url)+'" target="_blank" rel="noopener noreferrer">'+esc(r.url)+'</a></p>').join('')+'</div>';
}
function render(){const s=S[scene];document.body.dataset.scene=s.visual;$('kicker').textContent=s.kicker;$('slide-title').textContent=s.title;$('points').innerHTML=(s.subtitle?'<p class="cover-subtitle">'+esc(s.subtitle)+'</p>':'')+s.display_points.map(x=>'<p>'+esc(x)+'</p>').join('');$('takeaway').textContent=s.takeaway;$('visual').innerHTML=visual(s);$('visual').setAttribute('aria-label',s.title+' — veri görseli');$('source').textContent='Kaynak: '+s.source;$('source-right').textContent=[M.author,M.course].filter(Boolean).join(' · ');window.onSlideRendered?.(s);$('page').innerHTML='<b>'+String(scene+1).padStart(2,'0')+'</b> / '+S.length;$('clock').textContent=fmt(elapsed)+' / '+fmt(T);$('prev').disabled=scene===0;$('next').disabled=scene===S.length-1;[...$('track').children].forEach((b,i)=>{b.classList.toggle('active',i===scene);b.classList.toggle('done',i<scene);b.setAttribute('aria-current',i===scene?'step':'false')})}
function go(i){if(i<0||i>=S.length)return;scene=i;elapsed=offsets[i];render()}
for(const[i,s]of S.entries()){const b=document.createElement('button');b.title=(i+1)+'. '+s.title;b.setAttribute('aria-label',b.title);b.onclick=()=>go(i);$('track').append(b)}
function togglePlay(){playing=!playing;$('play').innerHTML=playing?'<span aria-hidden="true" class="pause-symbol"></span>':'<span aria-hidden="true" class="play-symbol"></span>';if(timer)clearInterval(timer);if(playing){if(elapsed>=T)go(0);timer=setInterval(()=>{elapsed++;if(elapsed>=T){elapsed=T;playing=false;clearInterval(timer);$('play').innerHTML='<span aria-hidden="true" class="play-symbol"></span>'}else if(elapsed>=offsets[scene+1]){scene++;render()}$('clock').textContent=fmt(elapsed)+' / '+fmt(T)},1000)}}
$('prev').onclick=()=>go(scene-1);$('next').onclick=()=>go(scene+1);$('play').onclick=togglePlay;
function openModal(title){priorFocus=document.activeElement;$('modal-title').textContent=title;$('modal-body').replaceChildren();$('modal').hidden=false;document.body.style.overflow='hidden';$('close-modal').focus();return $('modal-body')}
function closeModal(){if(map){map.remove();map=null}$('modal').hidden=true;document.body.style.overflow='';priorFocus?.focus()}
$('close-modal').onclick=closeModal;$('modal').onclick=e=>{if(e.target===$('modal'))closeModal()};
function referenceNode(r){const e=document.createElement('article');e.className='apa-entry';e.innerHTML='<p>'+r.apa+' <a href="'+esc(r.url)+'" target="_blank" rel="noopener noreferrer">'+esc(r.url)+'</a></p><small>'+esc(r.kind)+' · '+esc(r.access)+'</small><details><summary>Erişim kaydı</summary><p>'+esc(r.verification)+'</p></details>';return e}
function openReferences(){const body=openModal('Kaynakça / APA 7');for(const r of D.references)body.append(referenceNode(r))}
function openNotes(){const body=openModal('Anlatıcı kartları / '+fmt(T)+' anlatım + '+fmt(D.timing.session-T)+' pay');body.className='talk';for(const[i,s]of S.entries()){const e=document.createElement('article');e.className='cue-card';e.innerHTML='<h3>'+String(i+1)+'. '+esc(s.title)+'</h3><small>'+fmt(offsets[i])+'–'+fmt(offsets[i+1])+'</small><ul>'+s.cue_sentences.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ul><details><summary>Prova metni</summary><p>'+esc(s.full_notes)+'</p></details>';body.append(e)}}
$('notes-open').onclick=openNotes;$('refs-open').onclick=openReferences;
function download(name,text,type){const url=URL.createObjectURL(new Blob([text],{type})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function openEvidence(){const body=openModal('Veri, yöntem ve kayıt izleri');body.className='';body.innerHTML='<p>311 benzersiz gösterge. Son DNS etiketi, etkin kayıt sınırı, fiyat veya barındırma ülkesi değildir. Gövde tekrarı ortak operatör kanıtı sayılmaz.</p><div class="filter-controls"><input id="filter-text" type="search" placeholder="Etki­sizleştirilmiş alan adı" aria-label="Alan adı ara"><select id="filter-country" aria-label="Hedef ülke"><option value="">Bütün hedef etiketleri</option></select><button id="csv-export">Seçili kayıtları CSV indir</button></div><div class="table-wrap"><table><thead><tr><th>Gösterge</th><th>Hedef etiketi</th><th>İlk / son etiket</th><th>Kaynak sıra no</th></tr></thead><tbody id="evidence-rows"></tbody></table></div><p id="row-count"></p><details><summary>Kaynak ve dönüşüm kuralları</summary><p>350 ham kayıt; 313 alan adı satırı; 2 tekrar çıkarıldı. Hedef, kaynağın comment alanından alındı. İlk ve son DNS etiketlerinde tam dize eşitliği kullanıldı. Bütün ds değerleri 2022-09-27; faaliyet zaman analizi yapılmadı.</p><p id="source-hash"></p><a id="source-link" target="_blank" rel="noopener noreferrer">Sabit commit ile kaynak CSV ↗</a></details>';
 for(const[k,v]of Object.entries(countryNames))$('filter-country').append(new Option(v,k));let shown=[];
 function fill(){const q=$('filter-text').value.toLowerCase().trim(),country=$('filter-country').value;shown=D.analysis.records.filter(r=>(!country||r.source_target_label===country)&&(!q||r.defanged_domain.toLowerCase().includes(q)));$('evidence-rows').innerHTML=shown.map(r=>'<tr><td>'+esc(r.defanged_domain)+'</td><td>'+esc(countryNames[r.source_target_label])+'</td><td>'+esc(r.first_dns_label)+' / '+esc(r.last_dns_label)+'</td><td>'+r.source_record_ordinals.join(', ')+'</td></tr>').join('');$('row-count').textContent=shown.length+' / 311 benzersiz kayıt'}
 $('filter-text').oninput=fill;$('filter-country').onchange=fill;fill();$('source-link').href=D.analysis.source.url;$('source-hash').textContent='SHA-256: '+D.analysis.source.sha256;
 $('csv-export').onclick=()=>{const quote=x=>'"'+String(x).replaceAll('"','""')+'"';download('META_2022_YAPISAL_KANIT.csv','\uFEFF'+[['domain_defanged','source_target','first_dns_label','last_dns_label','source_ordinals'],...shown.map(r=>[r.defanged_domain,r.source_target_label,r.first_dns_label,r.last_dns_label,r.source_record_ordinals.join('|')])].map(row=>row.map(quote).join(',')).join('\r\n'),'text/csv;charset=utf-8')};
}
$('evidence-open').onclick=openEvidence;
function focusAtlas(key,animate=true){if(!map)return;$('atlas-focus').textContent=key==='Europe'?'Ülke düzeyindeki hedef etiketleri':countryNames[key]+' / '+D.analysis.findings.target_country_counts[key]+' benzersiz gösterge';if(key==='Europe'){if(animate)map.flyToBounds([[34,-13],[61,29]],{duration:1.2});else map.fitBounds([[34,-13],[61,29]]);return}const layer=atlasTargets[key];if(layer){const bounds=layer.getBounds();if(animate)map.flyToBounds(bounds,{padding:[50,50],duration:1.2,maxZoom:6.5});else map.fitBounds(bounds,{padding:[50,50],maxZoom:6.5});}}
function openAtlas(){atlasTargets={};const body=openModal('Hedef ülkeler / yardımcı harita');body.className='';body.innerHTML='<div id="atlas-country-tour" class="atlas-controls"></div><p id="atlas-focus" class="atlas-focus"></p><div class="atlas-wrap"><div id="atlas-map"></div><span id="atlas-status"></span></div><p class="atlas-note">Meta hedef etiketleri, ülke düzeyinde. Harita, operasyon konumu veya barındırma bilgisi göstermez. Çoklu hedef etiketi taşıyan 1 gösterge belirli bir ülkeye yerleştirilmez.</p>';map=L.map('atlas-map',{keyboard:false,zoomControl:true,minZoom:3,maxZoom:10,zoomSnap:.25});map.attributionControl.setPrefix('Leaflet 1.9.4');map.attributionControl.addAttribution('Sınırlar: Natural Earth');map.createPane('offline-land');map.getPane('offline-land').style.zIndex=180;
 const geo={type:'FeatureCollection',features:D.features.map(f=>({type:'Feature',properties:{name:f.name},geometry:{type:'MultiPolygon',coordinates:f.polygons}}))};
 L.geoJSON(geo,{pane:'offline-land',style:{fillColor:'#e3edf5',fillOpacity:1,color:'#607d96',weight:.7},interactive:false}).addTo(map);const basemap=attachBasemap(map,$('atlas-status'));
 const names={Germany:'Germany','United Kingdom':'UK',France:'France',Italy:'Italy',Latvia:'Latvia',Ukraine:'Ukraine'};
 L.geoJSON(geo,{style:f=>{const k=names[f.properties.name],n=k?D.analysis.findings.target_country_counts[k]:0;return{color:n?'#214a70':'#7e95a9',weight:n?1.2:.5,fillColor:k==='Germany'?'#b7382e':'#457eaa',fillOpacity:n?(k==='Germany'?.65:.35):0}},onEachFeature:(f,l)=>{const k=names[f.properties.name];if(k){atlasTargets[k]=l;const n=D.analysis.findings.target_country_counts[k];l.bindTooltip(countryNames[k]+' / '+n);l.bindPopup('<h3>'+esc(countryNames[k])+'</h3><p class="atlas-count">'+n+' benzersiz gösterge</p><p>Kaynağın hedef ülke etiketi; olay veya sunucu konumu değildir.</p>')}}}).addTo(map);for(const key of ['Europe','Germany','UK','France','Italy']){const b=document.createElement('button');b.textContent=key==='Europe'?'Avrupa':countryNames[key];b.dataset.country=key;b.onclick=()=>focusAtlas(key);$('atlas-country-tour').append(b)}focusAtlas('Europe',false);setTimeout(()=>map?.invalidateSize(false),100)}
$('atlas-open').onclick=openAtlas;
$('fullscreen').onclick=async()=>{document.body.classList.add('presentation');try{await document.documentElement.requestFullscreen()}catch(e){}window.scrollTo(0,0)};
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement)document.body.classList.remove('presentation')});
document.addEventListener('keydown',e=>{if(!$('modal').hidden){if(e.key==='Escape')closeModal();if(e.key==='Tab'){const items=[...$('modal').querySelectorAll('button,input,select,a[href],summary')].filter(x=>x.offsetParent!==null),first=items[0],last=items.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}return}if(['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName))return;if(e.key==='ArrowRight'){go(scene+1);e.preventDefault()}if(e.key==='ArrowLeft'){go(scene-1);e.preventDefault()}if(e.key===' '){go(scene+1);e.preventDefault()}if(e.key.toLowerCase()==='p'){togglePlay();e.preventDefault()}if(e.key.toLowerCase()==='n')openNotes()});
$('timing-label').textContent='YAKLAŞIK '+Math.round(T/60)+' DAKİKA · SLAYTLARI SUNUCU GEÇİRİR';
render();

/* ---------- Kendiliğinden ilerleyen sunum ----------
 * "Sunumu başlat": tam ekran + otomatik akış. Her slaytta maddeler sırayla açılır,
 * ana fikir sonda gelir, alttaki anlatım şeridi konuşma cümlelerini zamanında gösterir,
 * görseller (grafik, harita) slaytın süresine bağlı olarak kendiliğinden ilerler.
 * İsteğe bağlı sesli anlatım: tarayıcının Türkçe sesiyle (S tuşu).
 */
const TICK=.25;let lastCue=-1,captions=false,voice=false;
const cap=document.createElement('div');cap.id='caption';cap.setAttribute('aria-live','polite');document.querySelector('main.slide').append(cap);
const navBtn=(id,label,fn)=>{const b=document.createElement('button');b.id=id;b.textContent=label;b.onclick=fn;document.querySelector('header nav').prepend(b);return b};
const voiceBtn=navBtn('voice-toggle','Sesli anlatım: kapalı',()=>{voice=!voice;voiceBtn.textContent='Sesli anlatım: '+(voice?'açık':'kapalı');if(!voice)speechSynthesis?.cancel();else{lastCue=-1;progress()}});
const capBtn=navBtn('caption-toggle','Anlatım şeridi: kapalı',()=>{captions=!captions;capBtn.textContent='Anlatım şeridi: '+(captions?'açık':'kapalı');progress()});
function speak(text){try{if(!voice||!window.speechSynthesis)return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='tr-TR';u.rate=1.02;const v=speechSynthesis.getVoices().find(v=>v.lang&&v.lang.toLowerCase().startsWith('tr'));if(v)u.voice=v;speechSynthesis.speak(u)}catch(e){}}
function slideFraction(){const s=S[scene];return Math.min(1,Math.max(0,(elapsed-offsets[scene])/s.seconds))}
function progress(){
 const s=S[scene],f=slideFraction(),auto=playing||document.body.classList.contains('autoplay');
 const pts=[...$('points').children].filter(p=>!p.classList.contains('cover-subtitle'));
 pts.forEach((p,i)=>p.classList.toggle('pending',auto&&f<.06+i*(.62/Math.max(1,pts.length))));
 $('takeaway').classList.toggle('pending',auto&&f<.72);
 $('visual').classList.toggle('pending',auto&&f<.03);
 const cues=s.cue_sentences||[],k=Math.min(cues.length-1,Math.floor(f*cues.length));
 cap.hidden=!(captions&&auto&&cues.length);
 if(k!==lastCue&&cues.length){lastCue=k;cap.textContent=cues[k];if(auto)speak(cues[k])}
 window.onSlideProgress?.(s,f,auto);
}
const baseRender=render;render=function(){lastCue=-1;baseRender();progress()};
togglePlay=function(){
 playing=!playing;document.body.classList.toggle('autoplay',playing);
 $('play').innerHTML=playing?'<span aria-hidden="true" class="pause-symbol"></span>':'<span aria-hidden="true" class="play-symbol"></span>';
 if(timer)clearInterval(timer);if(!playing){speechSynthesis?.cancel?.();progress();return}
 if(elapsed>=T)go(0);
 timer=setInterval(()=>{elapsed+=TICK;if(elapsed>=T){elapsed=T;togglePlay();return}
  if(elapsed>=offsets[scene+1]){scene++;render()}else progress();
  $('clock').textContent=fmt(elapsed)+' / '+fmt(T);[...$('track').children].forEach((b,i)=>b.style.setProperty('--fill',i<scene?1:i>scene?0:slideFraction()))},TICK*1000);
 progress();
};
$('play').onclick=togglePlay;
$('fullscreen').textContent='Sunumu başlat ▶';
$('fullscreen').onclick=async()=>{document.body.classList.add('presentation');try{await document.documentElement.requestFullscreen()}catch(e){}window.scrollTo(0,0);if(elapsed>=T||scene===S.length-1)go(0);if(!playing)togglePlay()};
document.addEventListener('keydown',e=>{if(!$('modal').hidden||['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName))return;const k=e.key.toLowerCase();if(k==='s')voiceBtn.click();if(k==='c')capBtn.click()});
render();

/* ---------- Tek komutla başlatma: ?autoplay=1 (python sunum.py) ----------
 * Tarayıcılar tam ekranı yalnız bir tıklamayla izin verir: ekranda tek düğme çıkar;
 * tıklanmazsa 5 saniye sonra sunum tam ekransız da olsa kendiliğinden başlar.
 */
(function(){
 const q=new URLSearchParams(location.search);if(q.get('autoplay')!=='1'&&location.hash!=='#autoplay')return;
 document.body.classList.add('presentation');go(0);
 const o=document.createElement('div');o.id='start-overlay';o.innerHTML='<button id="start-now"><span>▶</span>Sunumu başlat</button><small>Tıklayın: tam ekran · →, Boşluk, PageDown ya da tıklama: sonraki slayt · ←: önceki · N: konuşma notları</small>';document.body.append(o);
 let done=false;
 async function begin(full){if(done)return;done=true;o.remove();startClock();if(full){try{await document.documentElement.requestFullscreen()}catch(e){}}}
 $('start-now').onclick=()=>begin(true);document.addEventListener('keydown',e=>{if(!done&&(e.key==='Enter'||e.key===' ')){e.preventDefault();e.stopImmediatePropagation();begin(true)}},true);
 $('start-now').focus();
})();

/* ---------- Sunucu kontrollü akış ----------
 * Slaytlar kendiliğinden geçmez ve yazılar süreyle açılmaz: her şey slayt açılınca görünür.
 * Yalnız harita (≈14 sn) ve haber dalgası grafiği (≈3 sn) slayta girince bir kez oynar.
 * Saat, sunumun başladığı andan itibaren geçen gerçek süreyi gösterir.
 */
let clockStart=null,clockTimer=null,animFrame=null;
function startClock(){if(clockStart)return;clockStart=Date.now();clockTimer=setInterval(()=>{if(!playing)$('clock').textContent=fmt((Date.now()-clockStart)/1000)+' / '+fmt(T)},500)}
function animateVisual(s){cancelAnimationFrame(animFrame);if(playing)return;const dur=s.visual==='gdelt_map'?14000:s.visual==='gdelt_wave'?3000:0;if(!dur)return;const t0=performance.now(),i=scene;
 const step=t=>{if(scene!==i||playing)return;const f=Math.min(1,(t-t0)/dur);window.onSlideProgress?.(s,f,f<1);if(f<1)animFrame=requestAnimationFrame(step)};animFrame=requestAnimationFrame(step)}
const renderManual=render;render=function(){renderManual();if(!clockStart)$('clock').textContent='00:00 / '+fmt(T);else if(!playing)$('clock').textContent=fmt((Date.now()-clockStart)/1000)+' / '+fmt(T);animateVisual(S[scene])};
document.addEventListener('keydown',e=>{if(!$('modal').hidden||['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName)||document.getElementById('start-overlay'))return;if(e.key==='PageDown'){startClock();go(scene+1);e.preventDefault()}if(e.key==='PageUp'){go(scene-1);e.preventDefault()}if(e.key==='ArrowRight')startClock()});
document.querySelector('main.slide').addEventListener('click',e=>{if(e.target.closest('a,button,input,select,label,.gdelt-slot,.leaflet-container')||document.getElementById('start-overlay'))return;startClock();go(scene+1)});
